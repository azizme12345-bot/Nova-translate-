LAFZ Translation website preview

Pages: index.html, privacy.html, content.html, about.html, image-translator.html
Assets: assets/style.css, assets/app.js, assets/logo.svg

Upload the complete folder contents to a static host to preview the layout. The text translation and image OCR controls call /api/translate and /api/ocr-translate; those endpoints require the original server/API project and its configured translation credentials. Browser microphone and speech playback require browser support and permission.

The Privacy Policy is a general draft and must be checked against the actual services and data retention settings before publishing.
